import React, { useState } from "react";
import Flex from "./layout/Flex";
import Image from "./layout/Image";
import SignUpImg from "../assets/sign-up.png";
import Container from "./layout/Container";
import Input from "./Input";
import { FaEyeSlash, FaEye } from "react-icons/fa";

const SignUp = () => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  // const [blindPassword, showPassword] = useState(false);
  const signInHandle = (e) => {
    e.preventDefault();
    if (email === "") {
      alert("set a email");
    }
    if (name === "") {
      alert("set a name");
    }
    if (password === "") {
      alert("set a password");
    }
  };
  const handlemail = (e) => {
    setEmail(e.target.value);
  };
  const handleName = (e) => {
    setName(e.target.value);
  };
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };
  // const eyeControll = (e) => {
  //   e.preventDefault();
  //   showPassword((prev) => !prev);
  // };

  return (
    <section>
      <Container>
        <Flex className="justify-between font-nunito items-center">
          <div className="ml-[150px]">
            <h1 className="text-[35px] font-bold">
              Get started with easily register
            </h1>
            <form action="">
              <Input
                type={"email"}
                labelName={"Email Address"}
                value={email}
                onChange={handlemail}
              />
              <Input
                type={"text"}
                labelName={"Full Name"}
                value={name}
                onChange={handleName}
              />
              <div className="relative mt-[40px] inline-block">
                <label className="text-[13px] text-[#11175D] font-semibold absolute bg-[#fff] px-[20px] top-[-10px] left-[35px]">
                  Password
                </label>
                <input
                  value={password}
                  onChange={handlePassword}
                  type={"password"}
                  className=" rounded-[10px] border-2 border-[#11175D] w-[360px] px-[10px] py-[10px] "
                />
                <FaEyeSlash className="absolute top-[15px] cursor-pointer size-[20px] right-[10px]" />
                <FaEye className="absolute top-[15px] cursor-pointer size-[20px] right-[10px]" />
              </div>
              <button
                onClick={signInHandle}
                className="rounded-[80px] px-[140px] py-[15px] bg-[#5F35F5] mt-[40px] text-5 font-semibold text-[#fff]"
              >
                Sign up
              </button>
            </form>
          </div>
          <Image imgClassName="h-[110vh]" src={SignUpImg} />
        </Flex>
      </Container>
    </section>
  );
};

export default SignUp;
